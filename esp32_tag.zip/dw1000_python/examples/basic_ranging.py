#!/usr/bin/env python3
"""
Basic ranging example using the DW1000 Python library.
This example shows how to perform distance measurement between two DW1000 devices.
"""

import time
import argparse
from dw1000_python import DW1000, DW1000Ranging
from dw1000_python.constants import DEFAULT_CONFIG

def main():
    parser = argparse.ArgumentParser(description='DW1000 ranging example')
    parser.add_argument('--mode', choices=['initiator', 'responder'], required=True,
                      help='Operating mode: initiator or responder')
    parser.add_argument('--bus', type=int, default=0,
                      help='SPI bus number (default: 0)')
    parser.add_argument('--device', type=int, default=0,
                      help='SPI device number (default: 0)')
    parser.add_argument('--reset-pin', type=int, default=17,
                      help='GPIO pin number for reset (default: 17)')
    parser.add_argument('--irq-pin', type=int, default=27,
                      help='GPIO pin number for interrupt (default: 27)')
    args = parser.parse_args()

    # Initialize DW1000
    try:
        dw = DW1000(bus=args.bus, device=args.device,
                    reset_pin=args.reset_pin, irq_pin=args.irq_pin)
    except Exception as e:
        print(f"Error initializing DW1000: {e}")
        return

    # Create ranging instance
    ranging = DW1000Ranging(dw)

    if args.mode == 'initiator':
        print("Running in initiator mode. Press Ctrl+C to stop.")
        try:
            while True:
                if ranging.initiate_ranging():
                    distance = ranging.compute_distance()
                    if distance is not None:
                        print(f"Measured distance: {distance:.2f} meters")
                    else:
                        print("Failed to compute distance")
                else:
                    print("Ranging sequence failed")
                time.sleep(1)
        except KeyboardInterrupt:
            print("\nStopping...")
    else:  # responder mode
        print("Running in responder mode. Press Ctrl+C to stop.")
        try:
            while True:
                # TODO: Implement responder mode
                # This would involve:
                # 1. Waiting for POLL message
                # 2. Sending RESPONSE message
                # 3. Waiting for FINAL message
                # 4. Computing distance
                time.sleep(0.1)
        except KeyboardInterrupt:
            print("\nStopping...")

if __name__ == '__main__':
    main() 