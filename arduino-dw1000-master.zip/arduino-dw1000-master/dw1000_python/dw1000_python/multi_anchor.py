"""Multi-anchor management for DW1000 devices."""

from typing import List, Dict, Optional
from .dw1000 import DW1000
from .ranging import DW1000Ranging
import numpy as np
import time
import threading

class MultiAnchorManager:
    def __init__(self, num_anchors: int = 4):
        """Initialize multiple DW1000 anchor devices.
        
        Args:
            num_anchors: Number of anchor devices to initialize (default: 4)
        """
        if num_anchors > 4:
            raise ValueError("Maximum 4 anchors supported")
            
        self.anchors: List[DW1000] = []
        self.ranging_modules: List[DW1000Ranging] = []
        self.distances: Dict[int, float] = {}
        self.lock = threading.Lock()
        
        # Initialize each anchor
        for i in range(num_anchors):
            try:
                anchor = DW1000(device_id=i)
                ranging = DW1000Ranging(anchor)
                self.anchors.append(anchor)
                self.ranging_modules.append(ranging)
                print(f"Initialized anchor {i}")
            except Exception as e:
                print(f"Failed to initialize anchor {i}: {e}")
                
        if not self.anchors:
            raise RuntimeError("No anchors were successfully initialized")

    def start_ranging(self):
        """Start ranging threads for all anchors."""
        self.running = True
        self.threads = []
        
        for i, ranging in enumerate(self.ranging_modules):
            thread = threading.Thread(target=self._ranging_thread, args=(i, ranging))
            thread.daemon = True
            thread.start()
            self.threads.append(thread)

    def stop_ranging(self):
        """Stop all ranging threads."""
        self.running = False
        for thread in self.threads:
            thread.join()

    def _ranging_thread(self, anchor_id: int, ranging: DW1000Ranging):
        """Thread function for continuous ranging on one anchor.
        
        Args:
            anchor_id: ID of the anchor this thread is handling
            ranging: Ranging module for this anchor
        """
        while self.running:
            try:
                distance = ranging.run_anchor_cycle()
                if distance is not None:
                    with self.lock:
                        self.distances[anchor_id] = distance
                time.sleep(0.01)  # Small delay to prevent busy-waiting
            except Exception as e:
                print(f"Error in anchor {anchor_id} ranging: {e}")
                time.sleep(1)  # Longer delay on error

    def get_distances(self) -> Dict[int, float]:
        """Get the latest distances from all anchors.
        
        Returns:
            Dictionary mapping anchor IDs to their latest measured distances
        """
        with self.lock:
            return self.distances.copy()

    def compute_position(self) -> Optional[np.ndarray]:
        """Compute tag position using multilateration (if enough measurements available).
        
        Returns:
            numpy array [x, y, z] of computed position, or None if not enough measurements
        """
        # Need at least 3 measurements for 2D positioning or 4 for 3D
        distances = self.get_distances()
        if len(distances) < 3:
            return None
            
        # TODO: Implement multilateration algorithm
        # This would use the known anchor positions and measured distances
        # to compute the tag's position
        return None

    def __del__(self):
        """Cleanup when object is destroyed."""
        self.stop_ranging()
        for anchor in self.anchors:
            del anchor 