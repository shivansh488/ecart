#!/usr/bin/env python3
"""
Multi-anchor ranging example using the DW1000 Python library.
This example shows how to use multiple DW1000 modules as anchors
to perform ranging with a mobile tag.
"""

import time
import argparse
from dw1000_python import MultiAnchorManager

def main():
    parser = argparse.ArgumentParser(description='DW1000 multi-anchor ranging example')
    parser.add_argument('--num-anchors', type=int, default=4,
                      help='Number of anchor modules (default: 4)')
    args = parser.parse_args()

    try:
        # Initialize the multi-anchor manager
        manager = MultiAnchorManager(num_anchors=args.num_anchors)
        print(f"Successfully initialized {args.num_anchors} anchors")

        # Start ranging
        manager.start_ranging()
        print("Started ranging. Press Ctrl+C to stop.")

        # Main loop
        while True:
            # Get latest distances
            distances = manager.get_distances()
            
            # Print distances for each anchor
            print("\nCurrent distances:")
            for anchor_id, distance in distances.items():
                print(f"Anchor {anchor_id}: {distance:.3f} meters")
            
            # Try to compute position if enough measurements
            position = manager.compute_position()
            if position is not None:
                print(f"Estimated position: {position}")
            
            time.sleep(1)  # Update once per second

    except KeyboardInterrupt:
        print("\nStopping...")
    except Exception as e:
        print(f"Error: {e}")
    finally:
        if 'manager' in locals():
            manager.stop_ranging()

if __name__ == '__main__':
    main() 