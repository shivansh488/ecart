from setuptools import setup, find_packages

setup(
    name="dw1000_python",
    version="0.1.0",
    packages=find_packages(),
    install_requires=[
        "spidev>=3.5",
        "RPi.GPIO>=0.7.0",
        "numpy>=1.19.0"
    ],
    author="Converted from Arduino DW1000 Library",
    author_email="your.email@example.com",
    description="A Python library for interfacing with the DW1000 UWB module on Raspberry Pi",
    long_description=open("README.md").read(),
    long_description_content_type="text/markdown",
    url="https://github.com/yourusername/dw1000_python",
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: POSIX :: Linux",
        "Topic :: System :: Hardware",
    ],
    python_requires=">=3.6",
) 