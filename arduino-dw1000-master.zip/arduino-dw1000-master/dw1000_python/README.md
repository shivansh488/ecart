# DW1000 Python Library

A Python library for interfacing with the DecaWave DW1000 Ultra-Wideband (UWB) transceiver module on Raspberry Pi. This library is a Python port of the Arduino DW1000 library.

## Features

- Basic DW1000 configuration and control
- Two-way ranging for distance measurement
- SPI communication via `spidev`
- GPIO control for reset and interrupt handling
- Timestamp management for precise timing
- Configurable antenna delay calibration

## Requirements

- Raspberry Pi (tested on Raspberry Pi 3B+ and 4)
- Python 3.6 or higher
- DW1000 module connected via SPI
- Required Python packages (installed automatically):
  - spidev
  - RPi.GPIO
  - numpy

## Installation

1. Enable SPI on your Raspberry Pi:
```bash
sudo raspi-config
# Navigate to Interface Options -> SPI -> Yes
```

2. Install the library using pip:
```bash
pip install dw1000-python
```

Or install from source:
```bash
git clone https://github.com/yourusername/dw1000-python.git
cd dw1000-python
pip install -e .
```

## Hardware Connection

Connect your DW1000 module to the Raspberry Pi:

- MOSI -> GPIO10 (MOSI)
- MISO -> GPIO9 (MISO)
- SCK -> GPIO11 (SCLK)
- CS -> GPIO8 (CE0) or GPIO7 (CE1)
- RST -> GPIO17 (configurable)
- IRQ -> GPIO27 (configurable)
- VDD -> 3.3V
- GND -> GND

## Basic Usage

```python
from dw1000_python import DW1000

# Initialize DW1000
dw = DW1000(bus=0, device=0)  # Using SPI0, CE0

# Basic transmit example
data = [0x01, 0x02, 0x03]
dw.start_transmit(data)

# Basic receive example
dw.start_receive()
# Process received data...

# Ranging example
from dw1000_python import DW1000Ranging

ranging = DW1000Ranging(dw)
if ranging.initiate_ranging():
    distance = ranging.compute_distance()
    print(f"Distance: {distance:.2f} meters")
```

## Advanced Configuration

The library supports various configuration options:

```python
from dw1000_python.constants import *

# Configure channel and preamble
dw.write_register(DW1000.CHAN_CTRL, [CHANNEL_5])
dw.write_register(DW1000.TX_FCTRL, [PREAMBLE_CODE_16MHZ_4])

# Set data rate
dw.write_register(DW1000.SYS_CFG, [TRX_RATE_6800KBPS])

# Configure antenna delay for ranging
ranging.set_antenna_delay(16384)  # Default value
```

## Contributing

Contributions are welcome! Please feel free to submit a Pull Request.

## License

This project is licensed under the MIT License - see the LICENSE file for details.

## Acknowledgments

This library is based on the Arduino DW1000 library and has been ported to Python for use with Raspberry Pi.

## Support

For issues, questions, or contributions, please visit the [GitHub repository](https://github.com/yourusername/dw1000-python). 