import spidev
import RPi.GPIO as GPIO
import time
from typing import Optional, List, Tuple
import numpy as np

class DW1000:
    # DW1000 Register addresses
    DEV_ID = 0x00
    EUI = 0x01
    PANADR = 0x03
    SYS_CFG = 0x04
    SYS_TIME = 0x06
    TX_FCTRL = 0x08
    TX_BUFFER = 0x09
    DX_TIME = 0x0A
    RX_FWTO = 0x0C
    SYS_CTRL = 0x0D
    SYS_MASK = 0x0E
    SYS_STATUS = 0x0F
    RX_FINFO = 0x10
    RX_BUFFER = 0x11
    RX_FQUAL = 0x12
    RX_TTCKI = 0x13
    RX_TTCKO = 0x14
    TX_POWER = 0x1E
    CHAN_CTRL = 0x1F
    USR_SFD = 0x21
    AGC_CTRL = 0x23
    EXT_SYNC = 0x24
    ACC_MEM = 0x25
    GPIO_CTRL = 0x26
    DRX_CONF = 0x27
    RF_CONF = 0x28
    TX_CAL = 0x2A
    FS_CTRL = 0x2B
    AON = 0x2C
    OTP_IF = 0x2D
    LDE_CTRL = 0x2E
    DIG_DIAG = 0x2F
    PMSC = 0x36

    def __init__(self, device_id: int = 0):
        """Initialize DW1000 device.
        
        Args:
            device_id: Device ID (0-3) to select which module to use
        """
        # Pin mappings for multiple devices
        self.CS_PINS = {
            0: 8,   # GPIO 8 (CE0)
            1: 7,   # GPIO 7 (CE1)
            2: 5,   # GPIO 5
            3: 6    # GPIO 6
        }
        
        self.IRQ_PINS = {
            0: 17,  # GPIO 17
            1: 27,  # GPIO 27
            2: 22,  # GPIO 22
            3: 23   # GPIO 23
        }
        
        self.RESET_PIN = 4  # Shared reset pin (GPIO 4)
        
        if device_id not in self.CS_PINS:
            raise ValueError("Invalid device_id. Must be 0-3")
            
        self.device_id = device_id
        self.cs_pin = self.CS_PINS[device_id]
        self.irq_pin = self.IRQ_PINS[device_id]

        # Initialize SPI
        self.spi = spidev.SpiDev()
        # Use SPI bus 0 for all devices since they share the bus
        self.spi.open(0, 0)  # We'll handle CS manually
        self.spi.max_speed_hz = 1000000
        self.spi.mode = 0

        # Setup GPIO
        GPIO.setmode(GPIO.BCM)
        GPIO.setup(self.RESET_PIN, GPIO.OUT)
        GPIO.setup(self.cs_pin, GPIO.OUT)
        GPIO.setup(self.irq_pin, GPIO.IN)
        
        # Initialize CS pin high (inactive)
        GPIO.output(self.cs_pin, GPIO.HIGH)

        # Reset all devices if this is device 0
        if device_id == 0:
            self.reset_all()
        
        # Initialize the device
        self.initialize()

    def reset_all(self):
        """Reset all DW1000 devices using the shared reset pin."""
        GPIO.output(self.RESET_PIN, GPIO.LOW)
        time.sleep(0.1)
        GPIO.output(self.RESET_PIN, GPIO.HIGH)
        time.sleep(0.1)

    def select(self):
        """Select this device (pull CS low)."""
        GPIO.output(self.cs_pin, GPIO.LOW)

    def deselect(self):
        """Deselect this device (pull CS high)."""
        GPIO.output(self.cs_pin, GPIO.HIGH)

    def read_register(self, address: int, length: int) -> List[int]:
        """Read from a DW1000 register.
        
        Args:
            address: Register address
            length: Number of bytes to read
            
        Returns:
            List of bytes read from the register
        """
        header = [(address << 1) & 0x7E]  # Read operation
        self.select()
        result = self.spi.xfer2(header + [0] * length)[1:]
        self.deselect()
        return result

    def write_register(self, address: int, data: List[int]):
        """Write to a DW1000 register.
        
        Args:
            address: Register address
            data: List of bytes to write
        """
        header = [((address << 1) & 0x7E) | 0x80]  # Write operation
        self.select()
        self.spi.xfer2(header + data)
        self.deselect()

    def initialize(self):
        """Initialize the DW1000 with default configuration."""
        # Read device ID to verify communication
        dev_id = self.read_register(self.DEV_ID, 4)
        if dev_id[0] != 0xDECA:
            raise RuntimeError(f"Failed to find DW1000 device {self.device_id}")

        # Load default configuration
        # TODO: Add configuration settings based on your requirements
        pass

    def configure_for_ranging(self):
        """Configure the device for ranging operations."""
        # TODO: Implement ranging configuration
        pass

    def start_receive(self):
        """Enable receiver."""
        # TODO: Implement receiver activation
        pass

    def start_transmit(self, data: List[int]):
        """Transmit data.
        
        Args:
            data: List of bytes to transmit
        """
        # TODO: Implement data transmission
        pass

    def get_receive_timestamp(self) -> float:
        """Get the timestamp of the last received message.
        
        Returns:
            Timestamp in seconds
        """
        # TODO: Implement timestamp reading
        return 0.0

    def get_transmit_timestamp(self) -> float:
        """Get the timestamp of the last transmitted message.
        
        Returns:
            Timestamp in seconds
        """
        # TODO: Implement timestamp reading
        return 0.0

    def __del__(self):
        """Cleanup when object is destroyed."""
        try:
            self.spi.close()
            # Only cleanup GPIO if this is the last device
            if hasattr(self, 'device_id') and self.device_id == 3:
                GPIO.cleanup([self.RESET_PIN] + list(self.CS_PINS.values()) + list(self.IRQ_PINS.values()))
        except:
            pass 